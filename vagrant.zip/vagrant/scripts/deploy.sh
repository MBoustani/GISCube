#!/usr/bin/env bash

echo "Installing all dependencies"

sudo apt-get update

apt-get -y install git &> /dev/null
apt-get -y install mc vim &> /dev/null
apt-get -y install libproj-dev libgdal-dev python-gdal libgeos-dev &> /dev/null


echo "Installing Anaconda"

if [ ! -d /opt/anaconda ]; then
    wget http://repo.continuum.io/miniconda/Miniconda-latest-Linux-x86_64.sh -O /opt/miniconda.sh -q
    bash /opt/miniconda.sh -b -p /opt/anaconda/
    echo "export PATH=/opt/anaconda/bin/:$PATH" | sudo tee -a /etc/bashrc
    echo "export PATH=/opt/anaconda/bin/:$PATH" | sudo tee -a /etc/environment
    /opt/anaconda/bin/conda config --set always_yes yes
    /opt/anaconda/bin/conda config --add create_default_packages pip --add create_default_packages ipython
    /opt/anaconda/bin/conda update conda --yes
fi

/opt/anaconda/bin/conda install numpy
/opt/anaconda/bin/conda install ipython pip
/opt/anaconda/bin/conda install gdal --yes
/opt/anaconda/bin/conda install -c https://conda.binstar.org/jjhelmus gdal-data
/opt/anaconda/bin/conda install django --yes
/opt/anaconda/bin/conda install netcdf4 --yes
/opt/anaconda/bin/pip install django-dajaxice Pydap


sudo -u vagrant git clone https://github.com/MBoustani/GISCube.git GISCube
echo "export GDAL_DATA=/opt/anaconda/share/gdal" >> /home/vagrant/.bashrc



echo "Installing and running Webification"

mkdir /home/vagrant//w10n
wget -P /home/vagrant/w10n http://scifari.org/taiga/download/taiga-2.0.0-linux-x86_64-a.tar.gz -q
tar zxf /home/vagrant/w10n/taiga-2.0.0-linux-x86_64-a.tar.gz -C /home/vagrant/w10n
/home/vagrant/w10n/taiga-2.0.0-linux-x86_64-a/bin/taiga-service config -p 18080 -d /home/vagrant/GISCube/giscube_app/static/uploaded_files
/home/vagrant/w10n/taiga-2.0.0-linux-x86_64-a/bin/taiga-service start